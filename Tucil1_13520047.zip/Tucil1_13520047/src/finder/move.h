#pragma once

#include "../type.h"

Position move(Position currentPos, Direction arah);
int isPositionValid(Position pos, Size matrixSize);
